/*: - Copyright :  Bulldog Ventures Inc  ©  2020 */
import UIKit

/*:

- Variables

Create a variable called name and initialize it to the name of your favorite actor, singer, or sports celebrity */
var name: String = "Brenda"
/*:
- Displaying on the screen

Display the contents of name on the screen

 Change the value of name to your name*/
print(name)
name = "Brenda"
/*:
- Constants
 
Display the contents of name

Create a constant (let instead of var) called language and initialize it to "Swift"

Display the contents of the language constant on screen

Create 3 different constants and initialize them to hold integers of your choice. Name the constants a, b, and c

Create 3 constants that are doubles (they have decimal points) Initialize them with values of your choice. Name the constants d, e, and f*/
print(name)
let language: String = "Swift"
print(language)
let a = 1, b = 2, c = 3
let d: Double = 1.01
let e: Double = 2.02
let f: Double = 3.03
/*:
- Operators

Create an assortment of statements using the constants that you created that will perform the following actions - then display the equation and the result on the screen.*/
var resultMath =  Double(a) + Double(b) / Double(c) * d + f
var x = a + b / c
print(resultMath)
/*:
- Add two constants
 
-                print("a + b = " ) + (a + b)

Addition sample with at least 4 constants

Subtraction sample

Division sample

Multiplication sample*/
print("a + b = \(a + b)")
print("a + b = \(a - b)")
print("a + b = \(a * b)")
print("a + b = \(a / b)")
/*:
- If Statements
 
Use the following constants to solve the problems :*/
 
let temperature = 90
let raining = true
let time = "Morning"

/*: Write a statement that tells someone to wear shorts if it is over 80 degrees, and jeans if it is less than 80 degrees. Check with the temperature constant

Check the raining constant and tell the user if they need an umbrella or not

Check the time constant and if it is morning tell the user to go to school, if it is afternoon tell the user to go home, and if it is night tell the user to go to bed*/
if temperature > 80 {
    print("wear shorts")
} else {
    print("wear pants")
}
if raining{
    print("Use an umbrella")
} else {
    print("Use sunscreen")
}

switch time {
    case "Morning":
        print("go to school")
    case "Afternoon":
        print("Time to go home")
    case "Evening":
        print("go to bed")
    default:
        print("no idea")
}
/*:
- Loops

Using a for loop print the numbers from 1 to 10 on screen

Using  a while loop print the numbers from 10 to 1 on screen*/
for i in 1...10 {
    print(i)
}

var i = 10
while i > 0 {
    print(i)
    i-=1
}
/*:
- Collections

Create an array that holds five strings

Create a tuple that holds two strings

Using a loop, step through one of the collections you created and print all of the items to the screen*/
var arra: [String] = ["shirts", "pants", "hats", "jackets", "sweaters"]
var coord = ("hi, hello")
for item in arra {
    print(item)
}
/*:
- Functions

Create a function that takes two doubles, multiplies them, and returns the result.

Call the function, save the result in the variable "answer". Pass it two of the constants you  creataed (a, b, c, d, e, or f)*/
func multiTwoNum(num1: Double, num2: Double) -> Double{
    return num1 + num2
}

var answer = multiTwoNum(num1: e, num2: f)
/*:
- Closures

Create a closure that subtracts one number from another and prints the results, use the closure. You may pass it constants or numbers*/
var closure = {
    (num1: Int, num2: Int) in
    print(num1 - num2)
}
closure(3,4)
/*:
- Enums
 
Create an enum that holds the first name of everyone in your group

Create a switch statement based on the enum that will display the birthday of the
selected person

Test it by using your own name*/
enum nameGame: String, CaseIterable{
        case name = "Brian"
        case name2 = "Brenda"
        case name3 = "Sabrina"
        case name4 = "Christina"
        case name5 = "Nina"
}

var myName = nameGame.name
    switch myName {
    case .name, .name2:
        print("Happy Birthday, \(nameGame.name.rawValue)!")
    default:
        print("Haooy Birthday!")
    }
/*:
- Structure
 
Create a structure called Name that holds a first, middle, and last name and prints them on screen in one line with spaces between them

Create an instance of the Name structure, pass it your name, and use the instance you created to print your  name to the screen*/
init(strFirst: String, strMiddle: String, strLast: String) {
    self.fName = strFirst
    self.mName = strMiddle
    self.lName = strLast
}
/*:
- Class
 
Create a class called Coffee that accepts size, caffineated,  cream,  and sugar then prints the order on screen

Create an instance of the class

Use the instance of the class and call the function*/
class Coffee {
    var theCupSize: cupSize
    var isCaffineated: Bool
    var hasCream: Bool
    var hasSugar: Bool
    
    enum cupSize: String, CaseIterable{
        case small = "S"
        case medium = "M"
        case large = "L"
        case keepMeAwakeThruMathClass = "XL"
    }
    init(incSize: cupSize, isCaffineated: Bool, hasCream: Bool, hasSugar: Bool) {
        self.theCupSize = incSize
        self.isCaffineated = isCaffineated
        self.hasCream = hasCream
        self.hasSugar = hasSugar
    }
}
 
func printAll(){
    print("My cup of coffee is \(TheCupSize.rawValue)")
    if isCaffineated {
        print("it is caffineated")
    } else {
        print("it is not caffineated")
    }
    if hasSugar {
        print("it has sugar")
    } else {
        print("it does not have sugar")
    }
    
    if hasCream {
        print("it has cream in it")
    } else {
        print("it does not have cream in it")
    }
}

var myCoffee = Coffee(incSize: .keepMeAwakeThruMathClass, isCaffineated: true, hasCream: true, hasSugar: true)
mycoffee.printAll()
